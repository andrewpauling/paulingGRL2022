#!/bin/bash

exp=$1
droot=/glade/work/apauling/pythonstuff/volcano_project/data/processed

for model in *; do
    echo $model

    if [ ! -d $model/$exp ]; then
	mkdir $model/$exp
    fi

    cp $droot/$model/$exp/*tseries* $model/$exp

done
